# SFL TURETA DATA V9

Added service hub and backend route scaffolding for:
- Airtime: MTN, Airtel, Glo, 9mobile
- Cable TV: DStv, GOtv, Startimes
- Electricity: supported DisCos
- Exam PIN: WAEC, NECO, JAMB, NABTEB

Live-release checklist:
1. Configure VTpass credentials on the backend only.
2. Map current VTpass service IDs/variation codes.
3. Apply wallet locking/atomic debit and refund logic.
4. Require Idempotency-Key for purchases.
5. Requery pending transactions and handle provider callbacks where supported.
6. Test sandbox before production.
7. Never put provider secret keys in the APK.
