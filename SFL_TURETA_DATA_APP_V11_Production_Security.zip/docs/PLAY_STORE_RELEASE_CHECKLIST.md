# Play Store Release Checklist

- [ ] Final Android app targets current Google Play API requirement.
- [ ] Production backend is HTTPS.
- [ ] Paystack live account and webhook configured.
- [ ] VTpass live API access approved and tested.
- [ ] Authorized NIN/BVN provider contract/API configured if offered.
- [ ] Database backups and monitoring configured.
- [ ] Admin MFA/strong authentication enabled.
- [ ] Privacy Policy and Data Safety declarations completed.
- [ ] Financial and identity-data flows tested.
- [ ] Signed Android App Bundle (.aab).
- [ ] Play App Signing configured.
- [ ] Closed testing completed where required by the developer account.
