# V10 — NIN/BVN + Reseller + Admin

## NIN/BVN
- NIN Check by Phone — ₦500
- BVN Check by Phone — ₦500
- NIN Information — ₦500
- BVN Information — ₦500
- Access restricted to `authorized_agent` or `admin`
- Sensitive values must be masked in UI/logs
- Every lookup must create an audit record
- Failed checks must not permanently charge the wallet

## Reseller
- Apply for reseller account
- Admin approval required
- Reseller dashboard
- Customer management
- Sales/profit tracking
- Withdrawal requests
- Referral support

## Admin
- User management
- Reseller approval/status
- Plans/pricing
- Transactions
- Withdrawals
- Profits
- Audit logs
- Notifications
- Security settings

Important: client apps must never be able to assign themselves `admin` or `authorized_agent`.
