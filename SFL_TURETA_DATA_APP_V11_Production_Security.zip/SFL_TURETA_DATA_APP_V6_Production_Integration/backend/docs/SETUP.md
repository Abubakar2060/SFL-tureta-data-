# Setup

## Requirements
- Node.js 18+
- PostgreSQL 14+

## 1. Install
npm install

## 2. Create database
Create PostgreSQL database named `sfl_tureta_data`.

## 3. Apply schema
psql "$DATABASE_URL" -f prisma/schema.sql

## 4. Environment
Copy `.env.example` to `.env` and replace secrets.

## 5. Run
npm run dev

Health check:
GET /health

## Important
This V1 is the backend foundation. Paystack webhook/verification and live data-provider fulfillment are intentionally not faked. Configure approved production providers before enabling real-money/live services.
