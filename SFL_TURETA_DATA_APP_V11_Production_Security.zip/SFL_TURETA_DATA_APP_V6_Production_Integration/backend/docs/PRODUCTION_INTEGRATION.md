# SFL TURETA DATA — V6 Production Integration

## Providers selected
- VTpass for Nigerian VTU/bills services.
- Paystack for wallet funding.

VTpass exposes Airtime, Data, Electricity, TV and Education services and provides sandbox/live API environments. Paystack initializes payments on the server and supports verification/webhooks.

## Required environment variables
Copy `.env.example` to `.env` and fill in real credentials. Never put `PAYSTACK_SECRET_KEY` or `VTPASS_SECRET_KEY` in the Android app.

### Sandbox first
`VTPASS_BASE_URL=https://sandbox.vtpass.com/api`
Use VTpass sandbox keys and Paystack test secret key.

### Live later
Change VTpass base URL to `https://vtpass.com/api` and use live credentials. Switch Paystack to live secret key.

## VTpass plan mapping
Every data plan must have:
- `provider_service_id` e.g. `mtn-data`
- `provider_variation_code` from VTpass variation endpoint
- `provider_cost`
- `customer_price`
- `reseller_price`

The app never trusts a client-provided price.

## Wallet funding
1. App requests `/api/v1/payments/paystack/initialize`.
2. Backend creates a pending WALLET_FUNDING transaction.
3. Backend initializes Paystack and returns `authorization_url` / `access_code`.
4. User completes payment.
5. Backend verifies the reference and amount/currency.
6. Backend credits the wallet exactly once using a DB lock and ledger entry.
7. Paystack webhook is accepted and processed idempotently.

## VTpass purchase
1. App sends plan ID, recipient phone and an Idempotency-Key.
2. Backend reads the current plan/provider mapping and locks the wallet.
3. Backend creates a pending transaction and debits the wallet atomically.
4. Backend calls VTpass.
5. Delivered => SUCCESS.
6. Failed/reversed => refund wallet exactly once.
7. Pending/timeout => keep PENDING and requery/webhook.

VTpass request IDs must start with the current Lagos date/time and be at least 12 characters. See the official VTpass docs for the exact request format and status rules.

## Go-live checklist
- Create VTpass sandbox account and keys.
- Create Paystack test keys.
- Configure PostgreSQL.
- Run `backend/prisma/schema.sql`.
- Test wallet funding, duplicate webhook, failed payment, data success, pending and refund.
- Configure VTpass callback URL: `POST /api/v1/provider/vtpass/webhook`.
- Configure Paystack webhook URL: `POST /api/v1/payments/paystack/webhook`.
- Add SMS/email OTP delivery provider; `ENABLE_DEV_OTP=true` is for development only.
- Replace wildcard CORS with the production domain.
- Put API behind HTTPS/TLS.
- Add monitoring, backups and alerting.
- Only after sandbox tests pass, request/enable live API access and live payment keys.
