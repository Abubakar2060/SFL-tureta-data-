const express=require('express');const cors=require('cors');const helmet=require('helmet');const rateLimit=require('express-rate-limit');const crypto=require('crypto');const db=require('./db');const config=require('./config');
const {requireAuth,requireRole,register,login,createPasswordOtp,verifyPasswordOtp,resetPassword}=require('./auth');
const {vtServices,vtVariations,vtPurchase,vtRequery,vtStatus,lagosRequestId,paystackInitialize,paystackVerify,verifyPaystackSignature}=require('./providers');
const app=express();app.use(helmet());app.use(cors({origin:config.corsOrigin}));
app.use('/api/v1/payments/paystack/webhook',express.raw({type:'application/json',limit:'100kb'}));app.use(express.json({limit:'100kb'}));
const authLimiter=rateLimit({windowMs:15*60*1000,max:50,standardHeaders:true,legacyHeaders:false});const otpLimiter=rateLimit({windowMs:15*60*1000,max:10,standardHeaders:true,legacyHeaders:false});
const rid=req=>req.headers['x-request-id']||`req_${crypto.randomBytes(8).toString('hex')}`;
const ok=(res,data,message='Request successful',status=200)=>res.status(status).json({success:true,data,message,request_id:rid(res.req)});
const fail=(res,code,message,status=400)=>res.status(status).json({success:false,error:{code,message},request_id:rid(res.req)});
const n=(v)=>Number(v||0);

app.get('/health',(req,res)=>ok(res,{service:'SFL TURETA DATA Backend',version:'V8',status:'ok',providers:{paystack:!!config.paystackSecretKey,vtpass:!!config.vtpassApiKey}}));
app.post('/api/v1/auth/register',authLimiter,async(req,res)=>{try{return ok(res,await register(req.body||{}),'Account created',201)}catch(e){return fail(res,e.code||'INTERNAL_ERROR',e.message||'Unable to create account',e.code==='DUPLICATE_REQUEST'?409:400)}});
app.post('/api/v1/auth/login',authLimiter,async(req,res)=>{try{return ok(res,await login(req.body||{}),'Login successful')}catch(e){return fail(res,e.code||'INTERNAL_ERROR',e.message||'Unable to login',e.code==='UNAUTHORIZED'?401:400)}});
app.post('/api/v1/auth/forgot-password',otpLimiter,async(req,res)=>{const id=String(req.body?.identifier||'').trim();if(!id)return fail(res,'INVALID_REQUEST','Phone or email is required');try{const r=await createPasswordOtp(id);const data={accepted:true};if(r.dev_otp)data.dev_otp=r.dev_otp;return ok(res,data,'If the account exists, an OTP has been sent')}catch(e){return fail(res,e.code||'INTERNAL_ERROR',e.message||'Request failed',400)}});
app.post('/api/v1/auth/verify-otp',otpLimiter,async(req,res)=>{try{return ok(res,await verifyPasswordOtp(String(req.body?.identifier||''),String(req.body?.otp||'')),'OTP verified')}catch(e){return fail(res,e.code||'INTERNAL_ERROR',e.message||'Invalid OTP',400)}});
app.post('/api/v1/auth/reset-password',otpLimiter,async(req,res)=>{try{return ok(res,await resetPassword(req.body?.reset_token,req.body?.new_password),'Password reset successful')}catch(e){return fail(res,e.code||'INTERNAL_ERROR',e.message||'Reset failed',400)}});
app.get('/api/v1/auth/me',requireAuth,async(req,res)=>{const r=await db.query('SELECT id,full_name,phone,email,role,status,created_at FROM users WHERE id=$1',[req.user.sub]);if(!r.rowCount)return fail(res,'USER_NOT_FOUND','User not found',404);return ok(res,{user:r.rows[0]})});
app.get('/api/v1/wallet',requireAuth,async(req,res)=>{const r=await db.query('SELECT user_id,balance,updated_at FROM wallets WHERE user_id=$1',[req.user.sub]);if(!r.rowCount)return fail(res,'USER_NOT_FOUND','Wallet not found',404);return ok(res,{wallet:r.rows[0]})});

app.post('/api/v1/payments/paystack/initialize',requireAuth,async(req,res)=>{const amount=n(req.body?.amount);if(!Number.isFinite(amount)||amount<100)return fail(res,'INVALID_REQUEST','Minimum funding amount is ₦100');const u=await db.query('SELECT id,email FROM users WHERE id=$1',[req.user.sub]);if(!u.rowCount)return fail(res,'USER_NOT_FOUND','User not found',404);const email=String(req.body?.email||u.rows[0].email||'').trim();if(!email)return fail(res,'INVALID_REQUEST','Email is required for wallet funding');const reference=`SFL_${Date.now()}_${crypto.randomBytes(5).toString('hex')}`;const c=await db.pool.connect();try{await c.query('BEGIN');const t=await c.query(`INSERT INTO transactions(user_id,type,service,amount,cost,profit,status,provider_reference,metadata) VALUES($1,'WALLET_FUNDING','Paystack', $2,$2,0,'PENDING',$3,$4) RETURNING id`,[req.user.sub,amount,reference,JSON.stringify({provider:'paystack'})]);await c.query('COMMIT');const p=await paystackInitialize({email,amountNaira:amount,reference,metadata:{transaction_id:t.rows[0].id,user_id:req.user.sub}});return ok(res,{transaction_id:t.rows[0].id,reference,authorization_url:p.data.authorization_url,access_code:p.data.access_code},'Payment initialized',201)}catch(e){await c.query('ROLLBACK').catch(()=>{});return fail(res,e.code||'PAYMENT_PROVIDER_ERROR',e.message||'Unable to initialize payment',400)}finally{c.release()}});

async function creditFunding(reference,payload){const c=await db.pool.connect();try{await c.query('BEGIN');const tr=await c.query(`SELECT * FROM transactions WHERE provider_reference=$1 FOR UPDATE`,[reference]);if(!tr.rowCount){await c.query('ROLLBACK');return {updated:false,reason:'NOT_FOUND'}};const t=tr.rows[0];if(t.status==='SUCCESS'){await c.query('COMMIT');return {updated:false,reason:'ALREADY_PROCESSED'}};if(payload.status!=='success'){await c.query(`UPDATE transactions SET status='FAILED',updated_at=NOW() WHERE id=$1`,[t.id]);await c.query('COMMIT');return {updated:true,status:'FAILED'}};const paidKobo=n(payload.amount);const expectedKobo=n(t.amount)*100;if(Math.round(paidKobo)!==Math.round(expectedKobo)||String(payload.currency||'NGN')!=='NGN'){await c.query(`UPDATE transactions SET status='FAILED',metadata=COALESCE(metadata,'{}'::jsonb)||$2::jsonb,updated_at=NOW() WHERE id=$1`,[t.id,JSON.stringify({payment_mismatch:true,provider_amount:payload.amount,provider_currency:payload.currency})]);await c.query('COMMIT');return {updated:true,status:'FAILED'}};const w=await c.query('SELECT balance FROM wallets WHERE user_id=$1 FOR UPDATE',[t.user_id]);if(!w.rowCount)throw new Error('Wallet not found');const before=n(w.rows[0].balance),after=before+n(t.amount);await c.query('UPDATE wallets SET balance=$1,updated_at=NOW() WHERE user_id=$2',[after,t.user_id]);await c.query(`INSERT INTO wallet_transactions(user_id,transaction_id,type,amount,balance_before,balance_after) VALUES($1,$2,'CREDIT',$3,$4,$5)`,[t.user_id,t.id,t.amount,before,after]);await c.query(`UPDATE transactions SET status='SUCCESS',updated_at=NOW(),metadata=COALESCE(metadata,'{}'::jsonb)||$2::jsonb WHERE id=$1`,[t.id,JSON.stringify({paid:true,paystack_id:payload.id||null})]);await c.query('COMMIT');return {updated:true,status:'SUCCESS',balance:after}}catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}

app.get('/api/v1/payments/paystack/verify/:reference',requireAuth,async(req,res)=>{try{const r=await db.query('SELECT * FROM transactions WHERE provider_reference=$1 AND user_id=$2',[req.params.reference,req.user.sub]);if(!r.rowCount)return fail(res,'USER_NOT_FOUND','Payment reference not found',404);const p=await paystackVerify(req.params.reference);const result=await creditFunding(req.params.reference,p.data||{});return ok(res,{provider_status:p.data?.status,reference:req.params.reference,...result},'Payment verified')}catch(e){return fail(res,e.code||'PAYMENT_PROVIDER_ERROR',e.message||'Unable to verify payment',400)}});

app.post('/api/v1/payments/paystack/webhook',async(req,res)=>{const raw=Buffer.isBuffer(req.body)?req.body:Buffer.from(JSON.stringify(req.body||{}));if(!verifyPaystackSignature(raw,req.headers['x-paystack-signature']))return res.status(401).json({success:false});res.status(200).json({response:'success'});setImmediate(async()=>{try{const ev=JSON.parse(raw.toString('utf8'));if(ev.event==='charge.success'&&ev.data?.reference)await creditFunding(ev.data.reference,{status:ev.data.status,amount:ev.data.amount,currency:ev.data.currency,id:ev.data.id})}catch(e){console.error('Paystack webhook processing failed',e)}})});

app.get('/api/v1/data/networks',requireAuth,async(req,res)=>{const r=await db.query("SELECT id,code,name,status FROM networks WHERE status='active' ORDER BY name");return ok(res,{networks:r.rows})});
app.get('/api/v1/data/plans',requireAuth,async(req,res)=>{const network=req.query.network;const q=network?"SELECT p.id,p.network_id,p.name,p.validity,p.customer_price,p.reseller_price,p.status,p.provider_service_id,p.provider_variation_code,n.code network_code FROM data_plans p JOIN networks n ON n.id=p.network_id WHERE p.status='active' AND n.code=$1 ORDER BY p.customer_price":"SELECT p.id,p.network_id,p.name,p.validity,p.customer_price,p.reseller_price,p.status,p.provider_service_id,p.provider_variation_code,n.code network_code FROM data_plans p JOIN networks n ON n.id=p.network_id WHERE p.status='active' ORDER BY p.customer_price";const r=await db.query(q,network?[network]:[]);return ok(res,{plans:r.rows})});
app.get('/api/v1/provider/services',requireAuth,async(req,res)=>{try{return ok(res,await vtServices(String(req.query.identifier||'data')))}catch(e){return fail(res,e.code||'PROVIDER_ERROR',e.message||'Provider error',400)}});
app.get('/api/v1/provider/variations',requireAuth,async(req,res)=>{const id=String(req.query.serviceID||'');if(!id)return fail(res,'INVALID_REQUEST','serviceID is required');try{return ok(res,await vtVariations(id))}catch(e){return fail(res,e.code||'PROVIDER_ERROR',e.message||'Provider error',400)}});

app.post('/api/v1/data/purchase',requireAuth,async(req,res)=>{const {plan_id,phone}=req.body||{};if(!plan_id||!/^0\d{10}$/.test(phone||''))return fail(res,'INVALID_REQUEST','Valid plan_id and Nigerian phone number are required');const idem=String(req.headers['idempotency-key']||'');if(!idem)return fail(res,'INVALID_REQUEST','Idempotency-Key header is required');const c=await db.pool.connect();let tx;try{await c.query('BEGIN');const existing=await c.query('SELECT * FROM transactions WHERE user_id=$1 AND idempotency_key=$2',[req.user.sub,idem]);if(existing.rowCount){await c.query('COMMIT');return ok(res,{transaction:existing.rows[0]},'Duplicate request safely ignored')}const p=await c.query('SELECT p.*,n.code network_code FROM data_plans p JOIN networks n ON n.id=p.network_id WHERE p.id=$1 AND p.status=\'active\'',[plan_id]);if(!p.rowCount){await c.query('ROLLBACK');return fail(res,'PLAN_NOT_FOUND','Data plan not found',404)}const plan=p.rows[0];if(!plan.provider_service_id||!plan.provider_variation_code){await c.query('ROLLBACK');return fail(res,'PLAN_NOT_CONFIGURED','This plan has not been mapped to a VTpass service yet',409)}const w=await c.query('SELECT balance FROM wallets WHERE user_id=$1 FOR UPDATE',[req.user.sub]);if(!w.rowCount){await c.query('ROLLBACK');return fail(res,'USER_NOT_FOUND','Wallet not found',404)}const balance=n(w.rows[0].balance),price=n(plan.customer_price);if(balance<price){await c.query('ROLLBACK');return fail(res,'INSUFFICIENT_BALANCE','Insufficient wallet balance',400)}const t=await c.query(`INSERT INTO transactions(user_id,type,service,plan_id,phone,amount,cost,profit,status,idempotency_key,metadata) VALUES($1,'DATA', $2,$3,$4,$5,$6,$7,'PENDING',$8,$9) RETURNING *`,[req.user.sub,plan.network_code,plan.id,phone,price,n(plan.provider_cost),price-n(plan.provider_cost),idem,JSON.stringify({provider:'vtpass',serviceID:plan.provider_service_id,variation_code:plan.provider_variation_code})]);await c.query('UPDATE wallets SET balance=balance-$1,updated_at=NOW() WHERE user_id=$2',[price,req.user.sub]);await c.query(`INSERT INTO wallet_transactions(user_id,transaction_id,type,amount,balance_before,balance_after) VALUES($1,$2,'DEBIT',$3,$4,$5)`,[req.user.sub,t.rows[0].id,price,balance,balance-price]);tx=t.rows[0];await c.query('COMMIT')}catch(e){await c.query('ROLLBACK').catch(()=>{});return fail(res,e.code||'INTERNAL_ERROR',e.message||'Purchase preparation failed',400)}finally{c.release()}
  try{const meta=tx.metadata||{};const vp=await vtPurchase({serviceID:meta.serviceID,variation_code:meta.variation_code,billersCode:phone,amount:n(tx.cost),phone,request_id:lagosRequestId('SFL')});const providerRef=vp.requestId||vp.content?.transactions?.transactionId||null;const status=vtStatus(vp);await db.query('UPDATE transactions SET status=$1,provider_reference=$2,updated_at=NOW(),metadata=COALESCE(metadata,\'{}\'::jsonb)||$3::jsonb WHERE id=$4',[status,providerRef,JSON.stringify({provider_response:vp}),tx.id]);if(status==='FAILED'||status==='REVERSED'){await refundTransaction(tx.id)}return ok(res,{transaction_id:tx.id,status,provider_reference:providerRef,provider_response:vp},'Data purchase processed',status==='PENDING'?202:200)}catch(e){await db.query("UPDATE transactions SET status='PENDING',updated_at=NOW() WHERE id=$1",[tx.id]);return ok(res,{transaction_id:tx.id,status:'PENDING'},'Provider is processing the request. Transaction status will be updated after requery/webhook.',202)}});

async function refundTransaction(transactionId){const c=await db.pool.connect();try{await c.query('BEGIN');const t=await c.query('SELECT * FROM transactions WHERE id=$1 FOR UPDATE',[transactionId]);if(!t.rowCount||['SUCCESS','REFUNDED'].includes(t.rows[0].status)){await c.query('COMMIT');return}const w=await c.query('SELECT balance FROM wallets WHERE user_id=$1 FOR UPDATE',[t.rows[0].user_id]);const before=n(w.rows[0].balance),after=before+n(t.rows[0].amount);await c.query('UPDATE wallets SET balance=$1,updated_at=NOW() WHERE user_id=$2',[after,t.rows[0].user_id]);await c.query(`INSERT INTO wallet_transactions(user_id,transaction_id,type,amount,balance_before,balance_after) VALUES($1,$2,'REFUND',$3,$4,$5)`,[t.rows[0].user_id,t.rows[0].id,t.rows[0].amount,before,after]);await c.query("UPDATE transactions SET status='REFUNDED',updated_at=NOW() WHERE id=$1",[transactionId]);await c.query('COMMIT')}catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}}

app.post('/api/v1/provider/requery',requireAuth,async(req,res)=>{const reference=String(req.body?.request_id||'');if(!reference)return fail(res,'INVALID_REQUEST','request_id is required');try{const p=await vtRequery(reference);const status=vtStatus(p);const r=await db.query('SELECT * FROM transactions WHERE provider_reference=$1 AND user_id=$2',[reference,req.user.sub]);if(r.rowCount){await db.query('UPDATE transactions SET status=$1,updated_at=NOW(),metadata=COALESCE(metadata,\'{}\'::jsonb)||$2::jsonb WHERE id=$3',[status,JSON.stringify({requery:p}),r.rows[0].id]);if(status==='FAILED'||status==='REVERSED')await refundTransaction(r.rows[0].id)}return ok(res,{status,provider_response:p})}catch(e){return fail(res,e.code||'PROVIDER_ERROR',e.message||'Requery failed',400)}});

app.get('/api/v1/transactions',requireAuth,async(req,res)=>{const r=await db.query('SELECT id,type,service,amount,cost,profit,status,provider_reference,created_at FROM transactions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100',[req.user.sub]);return ok(res,{transactions:r.rows})});
app.get('/api/v1/admin/dashboard',requireAuth,requireRole('admin'),async(req,res)=>{const [u,t,w]=await Promise.all([db.query('SELECT COUNT(*)::int AS count FROM users'),db.query("SELECT COUNT(*)::int AS count,COALESCE(SUM(amount),0) AS volume,COALESCE(SUM(profit),0) AS profit FROM transactions WHERE created_at::date=CURRENT_DATE AND status='SUCCESS'"),db.query('SELECT COALESCE(SUM(balance),0) AS wallet_balance FROM wallets')]);return ok(res,{users:u.rows[0],today:t.rows[0],wallets:w.rows[0]})});

app.post('/api/v1/provider/vtpass/webhook',async(req,res)=>{res.status(200).json({response:'success'});const ev=req.body||{};setImmediate(async()=>{try{if(ev.type!=='transaction-update')return;const d=ev.data||{},requestId=d.requestId,txId=d.content?.transactions?.transactionId;if(!requestId&&!txId)return;const q=requestId?await db.query('SELECT * FROM transactions WHERE provider_reference=$1',[requestId]):await db.query('SELECT * FROM transactions WHERE metadata->>\'vtpass_transaction_id\'=$1',[String(txId)]);if(!q.rowCount)return;const t=q.rows[0],status=vtStatus(d);await db.query('UPDATE transactions SET status=$1,metadata=COALESCE(metadata,\'{}\'::jsonb)||$2::jsonb,updated_at=NOW() WHERE id=$3',[status,JSON.stringify({webhook:d,vtpass_transaction_id:txId}),t.id]);if(status==='FAILED'||status==='REVERSED')await refundTransaction(t.id)}catch(e){console.error('VTpass webhook processing failed',e)}})});
app.use((err,req,res,next)=>{console.error(err);return fail(res,'INTERNAL_ERROR','Internal server error',500)});
app.listen(config.port,()=>console.log(`SFL TURETA DATA Backend V8 listening on port ${config.port}`));


// V9 service routes. Provider secrets stay on the backend.
app.get("/api/v1/services/catalog", async (req, res) => {
  res.json({
    success: true,
    data: {
      airtime: ["mtn", "airtel", "glo", "9mobile"],
      cable_tv: ["dstv", "gotv", "startimes"],
      electricity: ["aedc", "phed", "ikedc", "ekedc", "jed", "kedco"],
      exam_pin: ["waec", "neco", "jamb", "nabteb"]
    },
    message: "Service catalog"
  });
});

const providerNotConfigured = (req, res) => res.status(501).json({
  success: false,
  error: {
    code: "PROVIDER_NOT_CONFIGURED",
    message: "Configure VTpass credentials and current service mappings before live purchase."
  }
});

app.post("/api/v1/services/airtime/purchase", providerNotConfigured);
app.post("/api/v1/services/cable/purchase", providerNotConfigured);
app.post("/api/v1/services/electricity/purchase", providerNotConfigured);
app.post("/api/v1/services/exam-pin/purchase", providerNotConfigured);


// V10 NIN/BVN + Reseller + Admin protected route scaffolding.
// Real identity-verification provider credentials must remain backend-only.
const requireAdminOrAuthorizedAgent = (req, res, next) => {
  const role = req.user?.role;
  if (role !== "admin" && role !== "authorized_agent") {
    return res.status(403).json({
      success: false,
      error: { code: "FORBIDDEN", message: "Authorized agent/admin access required." }
    });
  }
  next();
};

app.post("/api/v1/verification/nin/check", requireAdminOrAuthorizedAgent, async (req, res) => {
  res.status(501).json({
    success: false,
    error: { code: "VERIFICATION_PROVIDER_NOT_CONFIGURED", message: "Configure an authorized NIN verification provider before live checks." }
  });
});

app.post("/api/v1/verification/bvn/check", requireAdminOrAuthorizedAgent, async (req, res) => {
  res.status(501).json({
    success: false,
    error: { code: "VERIFICATION_PROVIDER_NOT_CONFIGURED", message: "Configure an authorized BVN verification provider before live checks." }
  });
});

app.get("/api/v1/reseller/dashboard", async (req, res) => {
  res.json({ success: true, data: { sales: 0, profit: 0, customers: 0, withdrawals: 0 } });
});

app.post("/api/v1/reseller/apply", async (req, res) => {
  res.status(202).json({
    success: true,
    data: { status: "PENDING_APPROVAL" },
    message: "Reseller application submitted for admin approval."
  });
});

app.get("/api/v1/admin/dashboard", async (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ success: false, error: { code: "FORBIDDEN", message: "Admin access required." } });
  }
  res.json({
    success: true,
    data: { users: 0, resellers: 0, transactions: 0, revenue: 0, profit: 0, pendingWithdrawals: 0 }
  });
});
