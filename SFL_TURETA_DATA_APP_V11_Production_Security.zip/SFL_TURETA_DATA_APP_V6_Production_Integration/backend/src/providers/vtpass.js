const BASE = process.env.VTPASS_SANDBOX === "true"
  ? "https://sandbox.vtpass.com/api"
  : "https://vtpass.com/api";

function headers() {
  return {
    "api-key": process.env.VTPASS_API_KEY || "",
    "public-key": process.env.VTPASS_PUBLIC_KEY || "",
    "secret-key": process.env.VTPASS_SECRET_KEY || "",
    "Content-Type": "application/json"
  };
}

async function getServiceCategories() {
  const r = await fetch(`${BASE}/service-categories`, { headers: headers() });
  return r.json();
}

async function getServices(identifier) {
  const r = await fetch(`${BASE}/services?identifier=${encodeURIComponent(identifier)}`, {
    headers: headers()
  });
  return r.json();
}

async function getVariations(serviceID) {
  const r = await fetch(`${BASE}/service-variations?serviceID=${encodeURIComponent(serviceID)}`, {
    headers: headers()
  });
  return r.json();
}

module.exports = { getServiceCategories, getServices, getVariations };
