const crypto = require('crypto');
const config = require('./config');

function vtHeaders(method='GET') {
  const h = {'Content-Type':'application/json'};
  h['api-key'] = config.vtpassApiKey;
  h[method === 'GET' ? 'public-key' : 'secret-key'] = method === 'GET' ? config.vtpassPublicKey : config.vtpassSecretKey;
  return h;
}

async function vtpass(path, {method='GET', body}={}) {
  if (!config.vtpassApiKey || (method === 'GET' ? !config.vtpassPublicKey : !config.vtpassSecretKey)) {
    const e = new Error('VTpass credentials are not configured'); e.code='PROVIDER_NOT_CONFIGURED'; throw e;
  }
  const r = await fetch(`${config.vtpassBaseUrl}${path}`, {
    method, headers: vtHeaders(method), body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(config.providerTimeoutMs)
  });
  const text = await r.text();
  let data; try { data = JSON.parse(text); } catch { data = {raw:text}; }
  if (!r.ok) { const e=new Error('VTpass request failed'); e.code='PROVIDER_ERROR'; e.provider_status=r.status; e.provider_data=data; throw e; }
  return data;
}

function lagosRequestId(prefix='SFL') {
  const now = new Date(new Date().toLocaleString('en-US',{timeZone:'Africa/Lagos'}));
  const p = n => String(n).padStart(2,'0');
  return `${now.getFullYear()}${p(now.getMonth()+1)}${p(now.getDate())}${p(now.getHours())}${p(now.getMinutes())}${prefix}${crypto.randomBytes(6).toString('hex')}`;
}

function vtStatus(data) {
  const code = String(data?.code || '');
  const status = String(data?.content?.transactions?.status || '').toLowerCase();
  if (status === 'delivered') return 'SUCCESS';
  if (status === 'reversed' || code === '040') return 'REVERSED';
  if (['016','091'].includes(code) || status === 'failed') return 'FAILED';
  return 'PENDING';
}

async function vtVariations(serviceId) {
  return vtpass(`/service-variations?serviceID=${encodeURIComponent(serviceId)}`);
}

async function vtServices(identifier) {
  return vtpass(`/services?identifier=${encodeURIComponent(identifier)}`);
}

async function vtPurchase({serviceID, variation_code, billersCode, amount, phone, quantity, subscription_type, request_id}) {
  const payload = {request_id: request_id || lagosRequestId(), serviceID, phone};
  if (billersCode) payload.billersCode = billersCode;
  if (variation_code) payload.variation_code = variation_code;
  if (amount != null) payload.amount = amount;
  if (quantity != null) payload.quantity = quantity;
  if (subscription_type) payload.subscription_type = subscription_type;
  return vtpass('/pay',{method:'POST',body:payload});
}

async function vtRequery(request_id) {
  return vtpass('/requery',{method:'POST',body:{request_id}});
}

async function paystack(path,{method='GET',body}={}) {
  if (!config.paystackSecretKey) { const e=new Error('Paystack secret key is not configured'); e.code='PAYMENT_NOT_CONFIGURED'; throw e; }
  const r = await fetch(`https://api.paystack.co${path}`,{
    method,
    headers:{Authorization:`Bearer ${config.paystackSecretKey}`,'Content-Type':'application/json'},
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(config.providerTimeoutMs)
  });
  const text=await r.text(); let data; try{data=JSON.parse(text)}catch{data={raw:text}};
  if(!r.ok || data?.status===false){const e=new Error(data?.message||'Paystack request failed');e.code='PAYMENT_PROVIDER_ERROR';e.provider_status=r.status;e.provider_data=data;throw e;}
  return data;
}

async function paystackInitialize({email,amountNaira,reference,metadata}) {
  return paystack('/transaction/initialize',{method:'POST',body:{email,amount:String(Math.round(Number(amountNaira)*100)),currency:'NGN',reference,callback_url:config.paystackCallbackUrl||undefined,metadata}});
}

async function paystackVerify(reference) { return paystack(`/transaction/verify/${encodeURIComponent(reference)}`); }
function verifyPaystackSignature(rawBody, signature) {
  if(!config.paystackSecretKey || !signature) return false;
  const hash=crypto.createHmac('sha512',config.paystackSecretKey).update(rawBody).digest('hex');
  return crypto.timingSafeEqual(Buffer.from(hash),Buffer.from(String(signature)));
}

module.exports={vtServices,vtVariations,vtPurchase,vtRequery,vtStatus,lagosRequestId,paystackInitialize,paystackVerify,verifyPaystackSignature};
