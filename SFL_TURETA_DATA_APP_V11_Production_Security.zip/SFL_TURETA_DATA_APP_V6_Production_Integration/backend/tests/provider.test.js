const test=require('node:test');
const assert=require('node:assert/strict');
process.env.VTPASS_API_KEY='x';process.env.VTPASS_PUBLIC_KEY='PK_x';process.env.VTPASS_SECRET_KEY='SK_x';process.env.PAYSTACK_SECRET_KEY='sk_x';process.env.JWT_SECRET='x';
const p=require('../src/providers');
test('VTpass status mapping',()=>{assert.equal(p.vtStatus({code:'000',content:{transactions:{status:'delivered'}}}),'SUCCESS');assert.equal(p.vtStatus({code:'040',content:{transactions:{status:'reversed'}}}),'REVERSED');assert.equal(p.vtStatus({code:'016',content:{transactions:{status:'failed'}}}),'FAILED');assert.equal(p.vtStatus({code:'099',content:{transactions:{status:'pending'}}}),'PENDING')});
test('VTpass request id has required Lagos date prefix and length',()=>{const id=p.lagosRequestId('SFL');assert.match(id,/^\d{12}[A-Za-z0-9]+$/);assert.ok(id.length>=12)});
