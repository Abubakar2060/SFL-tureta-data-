# SFL TURETA DATA — Backend V1

Production-oriented Node.js/Express + PostgreSQL foundation for:

- Customer accounts
- Reseller accounts
- Admin role
- Wallet ledger foundation
- Data networks/plans
- Data purchase transaction foundation
- Transaction history
- Admin dashboard
- Audit/security-ready database structure

## Architecture

Android APK → Secure Backend API → PostgreSQL + Payment/Data Provider APIs

## Current status

This ZIP is a real source-code backend foundation, not a fake/demo transaction system.

Before production:
1. Configure PostgreSQL.
2. Set strong environment secrets.
3. Add approved Paystack integration and webhook verification.
4. Add approved data-provider API and fulfillment/reversal logic.
5. Add authorized NIN/BVN provider integrations.
6. Add HTTPS, rate limiting, monitoring, backups and deployment.
7. Create the first admin securely on the server/database; never allow public self-registration as admin.

See `docs/SETUP.md` and `docs/API.md`.
