plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.sflturetatdata.app"; compileSdk=36
 defaultConfig { applicationId="com.sflturetatdata.app"; minSdk=24; targetSdk=36; versionCode=6; versionName="6.0" }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.activity:activity-compose:1.10.1")
 implementation("androidx.compose.ui:ui:1.7.6")
 implementation("androidx.compose.material3:material3:1.3.1")
 implementation("androidx.compose.ui:ui-tooling-preview:1.7.6")
 implementation("com.squareup.okhttp3:okhttp:4.12.0")
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
 debugImplementation("androidx.compose.ui:ui-tooling:1.7.6")
}
