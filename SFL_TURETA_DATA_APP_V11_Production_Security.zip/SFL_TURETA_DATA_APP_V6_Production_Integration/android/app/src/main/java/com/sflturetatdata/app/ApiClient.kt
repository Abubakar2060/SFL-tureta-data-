package com.sflturetatdata.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

object ApiClient {
    // Replace with your deployed HTTPS backend URL.
    const val BASE_URL = "https://api-dev.sflturetatdata.com/api/v1"
    private val client = OkHttpClient()
    private val json = "application/json".toMediaType()

    suspend fun post(path:String, body:String, token:String?=null): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val b = body.toRequestBody(json)
            val rb = Request.Builder().url(BASE_URL + path).post(b)
            if (!token.isNullOrBlank()) rb.header("Authorization","Bearer $token")
            client.newCall(rb.build()).execute().use { r ->
                val text = r.body?.string().orEmpty()
                if (!r.isSuccessful) error("HTTP ${r.code}: $text")
                text
            }
        }
    }

    suspend fun postWithHeaders(path:String, body:String, token:String, headers:Map<String,String> = emptyMap()): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val b = body.toRequestBody(json)
            val rb = Request.Builder().url(BASE_URL + path).post(b)
                .header("Authorization","Bearer $token")
            headers.forEach { (k,v) -> rb.header(k,v) }
            client.newCall(rb.build()).execute().use { r ->
                val text = r.body?.string().orEmpty()
                if (!r.isSuccessful) error("HTTP ${r.code}: $text")
                text
            }
        }
    }

    suspend fun get(path:String, token:String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val rb = Request.Builder().url(BASE_URL + path).get()
                .header("Authorization","Bearer $token").build()
            client.newCall(rb).execute().use { r ->
                val text=r.body?.string().orEmpty()
                if (!r.isSuccessful) error("HTTP ${r.code}: $text")
                text
            }
        }
    }
}
