package com.sflturetatdata.app

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContent { SflApp() }
    }
}

data class Service(val title:String, val subtitle:String, val icon:String)

private val services = listOf(
    Service("Data", "MTN • Airtel • Glo • 9mobile", "📱"),
    Service("Airtime", "Top-up for any network", "💳"),
    Service("Bills", "Electricity • Internet", "💡"),
    Service("Cable TV", "DStv • GOtv • Startimes", "📺"),
    Service("Education", "JAMB • WAEC • NECO • NABTEB", "🎓"),
    Service("NIN / BVN", "Authorized verification services", "🪪"),
    Service("Wallet", "Fund • Transfer • Withdraw", "💰"),
    Service("Transactions", "History and receipts", "🧾"),
    Service("Reseller", "Customers • Sales • Profit", "👥")
)

@Composable
fun SflApp() {
    var page by remember { mutableStateOf("home") }
    var token by remember { mutableStateOf<String?>(null) }
    var userName by remember { mutableStateOf("Guest") }
    var selected by remember { mutableStateOf<Service?>(null) }

    if (token == null && page == "home") {
        LoginScreen(
            onLoggedIn = { t, name -> token=t; userName=name; page="home" },
            onRegister = { page="register" },
            onForgot = { page="forgot" }
        )
        return
    }
    if (page == "register") {
        RegisterScreen(onBack={page="home"}, onLoggedIn={t,name->token=t;userName=name;page="home"})
        return
    }
    if (page == "forgot") {
        ForgotPasswordScreen(onBack={page="home"})
        return
    }

    MaterialTheme {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(page=="home", {page="home"}, label={Text("Home")}, icon={Text("⌂")})
                    NavigationBarItem(page=="services", {page="services"}, label={Text("Services")}, icon={Text("▦")})
                    NavigationBarItem(page=="history", {page="history"}, label={Text("Transactions")}, icon={Text("◷")})
                    NavigationBarItem(page=="wallet", {page="wallet"}, label={Text("Wallet")}, icon={Text("▣")})
                    NavigationBarItem(page=="profile", {page="profile"}, label={Text("Profile")}, icon={Text("●")})
                }
            }
        ) { padding ->
            when(page) {
                "services" -> ServicesScreen(Modifier.padding(padding), onSelect={selected=it;page="service"})
                "service" -> ServiceDetail(Modifier.padding(padding), selected, token, onBack={page="services"})
                "history" -> HistoryScreen(Modifier.padding(padding), token)
                "wallet" -> WalletScreen(Modifier.padding(padding), token)
                "profile" -> ProfileScreen(Modifier.padding(padding), token, userName, onLogout={token=null;page="home"}, onForgot={page="forgot"})
                else -> HomeScreen(Modifier.padding(padding), userName, onServices={page="services"}, onWallet={page="wallet"})
            }
        }
    }
}

@Composable
fun Header(title:String="Dashboard") {
    Surface(color=MaterialTheme.colorScheme.primary, modifier=Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
            Text("SFL", color=MaterialTheme.colorScheme.onPrimary, fontWeight=FontWeight.Bold, style=MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.width(10.dp))
            Column { Text("SFL TURETA DATA", color=MaterialTheme.colorScheme.onPrimary, fontWeight=FontWeight.Bold); Text(title, color=MaterialTheme.colorScheme.onPrimary.copy(alpha=.85f)) }
        }
    }
}

@Composable
fun LoginScreen(onLoggedIn:(String,String)->Unit,onRegister:()->Unit,onForgot:()->Unit) {
    var identifier by remember{mutableStateOf("")}; var password by remember{mutableStateOf("")}; var msg by remember{mutableStateOf("")}; val scope=rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.spacedBy(14.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        Spacer(Modifier.height(30.dp)); Text("SFL TURETA DATA",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold); Text("Data cikin sauƙi, a kowane lokaci.")
        OutlinedTextField(identifier,{identifier=it},label={Text("Phone Number / Email")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(password,{password=it},label={Text("Password")},modifier=Modifier.fillMaxWidth())
        Button(onClick={scope.launch{ApiClient.post("/auth/login",JSONObject().apply{put("login",identifier);put("password",password)}.toString()).onSuccess{r->val j=JSONObject(r);val d=j.optJSONObject("data");onLoggedIn(d?.optString("access_token").orEmpty(),d?.optJSONObject("user")?.optString("full_name").orEmpty())}.onFailure{msg=it.message? : "Login failed"}}},modifier=Modifier.fillMaxWidth()){Text("Login")}
        TextButton(onClick=onForgot){Text("Forgot Password?")}; OutlinedButton(onClick=onRegister,modifier=Modifier.fillMaxWidth()){Text("Create Account")}
        if(msg.isNotBlank()) Text(msg)
    }
}

@Composable
fun RegisterScreen(onBack:()->Unit,onLoggedIn:(String,String)->Unit) {
    var name by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var email by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")};var msg by remember{mutableStateOf("")};val scope=rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("Create Account",style=MaterialTheme.typography.headlineMedium);OutlinedTextField(name,{name=it},label={Text("Full name")},modifier=Modifier.fillMaxWidth());OutlinedTextField(phone,{phone=it},label={Text("Phone")},modifier=Modifier.fillMaxWidth());OutlinedTextField(email,{email=it},label={Text("Email (optional)")},modifier=Modifier.fillMaxWidth());OutlinedTextField(pass,{pass=it},label={Text("Password (8+ characters)")},modifier=Modifier.fillMaxWidth());Button(onClick={scope.launch{ApiClient.post("/auth/register",JSONObject().apply{put("full_name",name);put("phone",phone);put("email",email);put("password",pass)}.toString()).onSuccess{r->val d=JSONObject(r).optJSONObject("data");onLoggedIn(d?.optString("access_token").orEmpty(),d?.optJSONObject("user")?.optString("full_name").orEmpty())}.onFailure{msg=it.message?:"Registration failed"}}},modifier=Modifier.fillMaxWidth()){Text("Create Account")};TextButton(onClick=onBack){Text("Back to Login")};if(msg.isNotBlank())Text(msg)}
}

@Composable
fun ForgotPasswordScreen(onBack:()->Unit) {
    var step by remember{mutableStateOf(1)};var identifier by remember{mutableStateOf("")};var otp by remember{mutableStateOf("")};var resetToken by remember{mutableStateOf("")};var newPass by remember{mutableStateOf("")};var msg by remember{mutableStateOf("")};val scope=rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Reset Password",style=MaterialTheme.typography.headlineMedium);when(step){1->{OutlinedTextField(identifier,{identifier=it},label={Text("Phone or Email")},modifier=Modifier.fillMaxWidth());Button(onClick={scope.launch{ApiClient.post("/auth/forgot-password",JSONObject().apply{put("identifier",identifier)}.toString()).onSuccess{step=2;msg="If the account exists, an OTP has been sent."}.onFailure{msg=it.message?:"Request failed"}}},modifier=Modifier.fillMaxWidth()){Text("Send OTP")}};2->{OutlinedTextField(otp,{otp=it},label={Text("6-digit OTP")},modifier=Modifier.fillMaxWidth());Button(onClick={scope.launch{ApiClient.post("/auth/verify-otp",JSONObject().apply{put("identifier",identifier);put("otp",otp)}.toString()).onSuccess{resetToken=JSONObject(it).optJSONObject("data")?.optString("reset_token").orEmpty();step=3}.onFailure{msg=it.message?:"Invalid OTP"}}},modifier=Modifier.fillMaxWidth()){Text("Verify OTP")}};3->{OutlinedTextField(newPass,{newPass=it},label={Text("New Password")},modifier=Modifier.fillMaxWidth());Button(onClick={scope.launch{ApiClient.post("/auth/reset-password",JSONObject().apply{put("reset_token",resetToken);put("new_password",newPass)}.toString()).onSuccess{msg="Password reset successful. Return to Login.";step=4}.onFailure{msg=it.message?:"Reset failed"}}},modifier=Modifier.fillMaxWidth()){Text("Save New Password")}};4->{Text("Password reset successful.");Button(onClick=onBack){Text("Go to Login")}}};if(msg.isNotBlank())Text(msg);if(step<4)TextButton(onClick=onBack){Text("Cancel")}}
}

@Composable
fun HomeScreen(m:Modifier,name:String,onServices:()->Unit,onWallet:()->Unit){Column(m.fillMaxSize().background(MaterialTheme.colorScheme.surface)){Header();Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Text("Welcome, $name",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(18.dp)){Text("Wallet Balance");Text("₦0.00",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick=onWallet){Text("Fund Wallet")};OutlinedButton(onClick=onWallet){Text("History")}}}};Text("Quick Services",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Quick("📱","Data",onServices);Quick("💳","Airtime",onServices);Quick("💡","Bills",onServices);Quick("🎓","Education",onServices)};Text("Our Services",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);services.take(6).chunked(3).forEach{row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){row.forEach{s->ServiceCard(s,onServices)}}}}}}
@Composable fun Quick(icon:String,title:String,onClick:()->Unit){Card(Modifier.weight(1f).clickable{onClick()}){Column(Modifier.padding(10.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(icon,style=MaterialTheme.typography.headlineSmall);Text(title)}}}
@Composable fun ServiceCard(s:Service,onClick:()->Unit){Card(Modifier.weight(1f).clickable{onClick()}){Column(Modifier.padding(12.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(s.icon,style=MaterialTheme.typography.headlineSmall);Text(s.title,fontWeight=FontWeight.Bold);Text(s.subtitle,style=MaterialTheme.typography.bodySmall)}}}

@Composable fun ServicesScreen(m:Modifier,onSelect:(Service)->Unit){LazyColumn(m.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Our Services",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)};items(services){s->Card(Modifier.fillMaxWidth().clickable{onSelect(s)}){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text(s.icon,style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.width(12.dp));Column{Text(s.title,fontWeight=FontWeight.Bold);Text(s.subtitle)}}}}}}

data class DataPlanUi(val id:String,val name:String,val validity:String,val price:Double,val network:String)

@Composable fun ServiceDetail(m:Modifier,s:Service?,token:String?,onBack:()->Unit){
    Column(m.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        TextButton(onClick=onBack){Text("← Back")}
        Text(s?.icon+" "+(s?.title?:"Service"),style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text(s?.subtitle.orEmpty())
        when(s?.title){
            "Data" -> DataPurchaseScreen(token)
            "Airtime" -> { Text("Airtime purchase will use the same secure wallet flow."); Button(onClick={}){Text("Coming Next") } }
            "NIN / BVN" -> { Text("Authorized users only. Verification must be performed through an approved provider."); Button(enabled=token!=null,onClick={}){Text("Open Verification") } }
            else -> { Text("This service is being connected to the secure VTpass backend."); Button(onClick={}){Text("Coming Next") } }
        }
    }
}

@Composable
fun DataPurchaseScreen(token:String?) {
    val scope=rememberCoroutineScope()
    var network by remember{mutableStateOf("mtn")}
    var phone by remember{mutableStateOf("")}
    var plans by remember{mutableStateOf(listOf<DataPlanUi>())}
    var selected by remember{mutableStateOf<DataPlanUi?>(null)}
    var message by remember{mutableStateOf("")}
    var loading by remember{mutableStateOf(false)}
    var purchasing by remember{mutableStateOf(false)}

    LaunchedEffect(network, token) {
        if(token.isNullOrBlank()) return@LaunchedEffect
        loading=true
        ApiClient.get("/data/plans?network=$network", token).onSuccess { raw ->
            val arr=JSONObject(raw).optJSONObject("data")?.optJSONArray("plans")
            val list=mutableListOf<DataPlanUi>()
            if(arr!=null) for(i in 0 until arr.length()) {
                val o=arr.optJSONObject(i) ?: continue
                list.add(DataPlanUi(o.optString("id"),o.optString("name"),o.optString("validity"),o.optDouble("customer_price"),o.optString("network_code")))
            }
            plans=list
            selected=null
            message=if(list.isEmpty()) "Ba a samu plans ba. Admin ya kamata ya saita VTpass variation code." else ""
        }.onFailure { message=it.message ?: "Unable to load plans" }
        loading=false
    }

    Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("1. Zaɓi Network",fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth()) {
            listOf("mtn" to "MTN","airtel" to "Airtel","glo" to "Glo","9mobile" to "9mobile").forEach { (code,label) ->
                FilterChip(selected=network==code,onClick={network=code},label={Text(label)})
            }
        }
        OutlinedTextField(phone,{phone=it.filter(Char::isDigit)},label={Text("Lambar waya")},placeholder={Text("08012345678")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        Text("2. Zaɓi Data Plan",fontWeight=FontWeight.Bold)
        if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        LazyColumn(modifier=Modifier.heightIn(max=300.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(plans) { plan ->
                Card(Modifier.fillMaxWidth().clickable{selected=plan},shape=RoundedCornerShape(12.dp)) {
                    Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(plan.name,fontWeight=FontWeight.Bold); if(plan.validity.isNotBlank()) Text(plan.validity,style=MaterialTheme.typography.bodySmall) }
                        Text("₦"+String.format("%,.2f",plan.price),fontWeight=FontWeight.Bold)
                        if(selected?.id==plan.id) Text(" ✓")
                    }
                }
            }
        }
        selected?.let { Text("Zaɓa: ${it.name} — ₦${String.format("%,.2f",it.price)}",fontWeight=FontWeight.Bold) }
        Button(enabled=token!=null && !purchasing && selected!=null && phone.matches(Regex("0\\d{10}")),onClick={
            val plan=selected ?: return@Button
            purchasing=true; message="Ana sarrafa sayan data..."
            scope.launch {
                val idem="data_${System.currentTimeMillis()}_${(100000..999999).random()}"
                ApiClient.postWithHeaders("/data/purchase",JSONObject().apply{put("plan_id",plan.id);put("phone",phone)}.toString(),token!!,mapOf("Idempotency-Key" to idem))
                    .onSuccess { raw ->
                        val d=JSONObject(raw).optJSONObject("data")
                        val status=d?.optString("status").orEmpty()
                        message=when(status){"SUCCESS"->"An kammala sayan data cikin nasara.";"FAILED","REVERSED"->"Sayan data ya gaza; idan an cire kuɗi, tsarin zai mayar da shi.";else->"An karɓi oda. Ana jiran tabbatarwar VTpass."}
                    }.onFailure { message=it.message ?: "Data purchase failed" }
                purchasing=false
            }
        },modifier=Modifier.fillMaxWidth()){Text(if(purchasing)"Ana sarrafa..." else "Buy Data")}
        if(message.isNotBlank()) Text(message,style=MaterialTheme.typography.bodySmall)
        Text("Kuɗi yana fita daga Wallet ne kawai bayan an tabbatar da farashin plan a backend. Ana amfani da VTpass don biyan data.",style=MaterialTheme.typography.bodySmall)
    }
}

@Composable fun WalletScreen(m:Modifier,token:String?){
 val scope=rememberCoroutineScope(); val context=LocalContext.current
 var balance by remember{mutableStateOf("₦0.00")}; var amount by remember{mutableStateOf("")}; var message by remember{mutableStateOf("")}; var loading by remember{mutableStateOf(false)}
 Column(m.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
  Header("Wallet")
  Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(20.dp)){Text("Available Balance",style=MaterialTheme.typography.labelLarge);Text(balance,style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Bold)}}
  Text("Fund Wallet",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
  OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Amount (₦)")},placeholder={Text("e.g. 1000")},modifier=Modifier.fillMaxWidth(),singleLine=true)
  Text("Minimum funding amount: ₦100",style=MaterialTheme.typography.bodySmall)
  Button(enabled=token!=null&&!loading,onClick={
   val value=amount.toDoubleOrNull(); if(value==null||value<100){message="Shigar da adadin da ya kai ₦100 ko fiye.";return@Button}; loading=true; message="Ana buɗe Paystack..."
   scope.launch{ApiClient.post("/payments/paystack/initialize",JSONObject().apply{put("amount",value)}.toString(),token).onSuccess{raw->loading=false;val d=JSONObject(raw).optJSONObject("data");val url=d?.optString("authorization_url").orEmpty();if(url.isNotBlank()){message="An shirya biyan kuɗi. Kammala shi a Paystack.";context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}else message="Ba a samu Paystack checkout link ba."}.onFailure{loading=false;message=it.message?:"Payment initialization failed"}}
  },modifier=Modifier.fillMaxWidth()){Text(if(loading)"Ana shirya..." else "Fund Wallet with Paystack")}
  OutlinedButton(enabled=token!=null,onClick={scope.launch{ApiClient.get("/wallet",token!!).onSuccess{raw->val w=JSONObject(raw).optJSONObject("data")?.optJSONObject("wallet");balance="₦"+String.format("%,.2f",w?.optDouble("balance",0.0)?:0.0);message="Balance updated."}.onFailure{message=it.message?:"Wallet request failed"}}},modifier=Modifier.fillMaxWidth()){Text("Refresh Balance")}
  if(message.isNotBlank())Text(message)
  Text("Payment is verified by the secure SFL TURETA DATA backend before your wallet is credited.",style=MaterialTheme.typography.bodySmall)
 }
}
@Composable fun HistoryScreen(m:Modifier,token:String?){val scope=rememberCoroutineScope();var result by remember{mutableStateOf("")};Column(m.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Transactions",style=MaterialTheme.typography.headlineMedium);Button(enabled=token!=null,onClick={scope.launch{ApiClient.get("/transactions",token!!).onSuccess{result=it}.onFailure{result=it.message?:"Request failed"}}}){Text("Refresh")};if(result.isNotBlank())Text(result)}}
@Composable fun ProfileScreen(m:Modifier,token:String?,name:String,onLogout:()->Unit,onForgot:()->Unit){Column(m.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Profile",style=MaterialTheme.typography.headlineMedium);Text(name,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Button(onClick=onForgot){Text("Forgot / Reset Password")};OutlinedButton(onClick={}){Text("Customer Care")};TextButton(onClick=onLogout){Text("Logout")}}}
