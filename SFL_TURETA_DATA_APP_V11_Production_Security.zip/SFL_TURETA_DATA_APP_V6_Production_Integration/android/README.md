# SFL TURETA DATA Android V4

Integrated UI foundation:
- Login / Register
- Forgot Password / OTP / Reset Password
- Dashboard
- Data, Airtime, Bills, Cable TV, Education, NIN/BVN, Wallet, Transactions, Reseller service cards
- Profile and Customer Care entry

IMPORTANT: Set `ApiClient.BASE_URL` to the deployed HTTPS backend URL before production use.
This package is source code. An Android SDK/Gradle environment is required to compile an APK.
