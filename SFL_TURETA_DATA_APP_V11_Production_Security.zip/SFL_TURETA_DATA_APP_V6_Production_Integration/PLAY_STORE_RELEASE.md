# Play Store release status

The Android project remains source code. Before publishing:
1. Set a production HTTPS API URL in the Android client.
2. Build a signed Android App Bundle (`.aab`).
3. Enable Google Play App Signing.
4. Complete privacy policy and Data Safety declarations.
5. Complete closed testing requirements if applicable to the developer account.
6. Move from provider sandbox/test keys to approved live credentials only after transaction testing.
