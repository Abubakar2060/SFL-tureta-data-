# SFL TURETA DATA — V8 Data Purchase

## User flow
1. Login
2. Services → Data
3. Select MTN, Airtel, Glo or 9mobile
4. Enter Nigerian phone number
5. Select active plan
6. Tap Buy Data
7. Backend validates current plan price and wallet balance
8. Backend locks wallet, creates transaction and debits wallet atomically
9. Backend sends purchase to VTpass
10. Success keeps the debit; failed/reversed status triggers a refund ledger entry; pending status is resolved by requery/webhook

## Provider requirements
VTpass API credentials must be configured on the backend. Each active data plan must have:
- `provider_service_id`
- `provider_variation_code`
- provider cost
- customer price

Do not put VTpass API keys in the Android APK.

## Important
This package is source code, not a signed production APK/AAB. Real provider credentials, database, HTTPS deployment, sandbox tests and live approval are required before production transactions.
