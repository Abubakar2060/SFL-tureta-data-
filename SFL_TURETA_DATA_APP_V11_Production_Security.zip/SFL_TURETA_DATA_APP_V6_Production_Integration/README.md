# SFL TURETA DATA — V6 Production Integration

This release connects the existing SFL TURETA DATA backend foundation to **VTpass** and **Paystack** at the server layer.

### Included
- Paystack wallet funding initialize/verify/webhook
- Atomic wallet credit + wallet ledger
- VTpass services and variation lookup
- VTpass data purchase flow
- Idempotency protection
- Wallet debit and automatic refund for failed/reversed purchases
- VTpass requery endpoint and webhook handler
- Production-oriented provider configuration
- Secure server-only provider credentials
- PostgreSQL schema additions for provider mapping and metadata

### Important
This is a **production integration source release**, not a final signed Google Play `.aab`. Real provider credentials, PostgreSQL hosting, HTTPS domain, OTP delivery, sandbox testing, live provider approval and Play Console signing/release are still required before public launch.


## V8 Data Purchase
The Android app now includes a real Data purchase flow backed by `/api/v1/data/plans` and `/api/v1/data/purchase`. Users choose MTN, Airtel, Glo or 9mobile, enter a Nigerian phone number, select a plan, and submit a purchase with an `Idempotency-Key`. The backend debits the wallet atomically, sends the purchase to VTpass, and refunds failed/reversed transactions.

VTpass requires sandbox/live API credentials and plan mappings (`provider_service_id` and `provider_variation_code`) before live purchases can work. VTpass documents Data Subscription API and callback/requery flows.
