package com.sfl.tureta.data

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun V10ServicesScreen(
    onNinBvn: () -> Unit,
    onReseller: () -> Unit,
    onAdmin: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("SFL TURETA DATA", style = MaterialTheme.typography.headlineSmall) }
        item { Text("Verification & Business") }

        item { ActionCard("🪪 NIN / BVN", "Authorized Agent/Admin only", onNinBvn) }
        item { ActionCard("👥 Reseller", "Sales • Customers • Profit • Withdrawals", onReseller) }
        item { ActionCard("🛠️ Admin Dashboard", "Users • Plans • Transactions • Security", onAdmin) }

        item {
            Text(
                "Access control ana aiwatar da shi a backend; ba daga app kawai ba.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            Text(subtitle)
            Spacer(Modifier.height(10.dp))
            Button(onClick = onClick) { Text("Buɗe") }
        }
    }
}
