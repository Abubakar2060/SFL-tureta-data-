package com.sfl.tureta.data

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ServicesV9Screen(
    onAirtime: () -> Unit,
    onCableTv: () -> Unit,
    onElectricity: () -> Unit,
    onExamPin: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("SFL TURETA DATA", style = MaterialTheme.typography.headlineSmall) }
        item { Text("Sauran ayyuka") }
        item { ServiceCard("📞 Airtime", "MTN • Airtel • Glo • 9mobile", onAirtime) }
        item { ServiceCard("📺 Cable TV", "DStv • GOtv • Startimes", onCableTv) }
        item { ServiceCard("💡 Electricity", "Supported DisCos", onElectricity) }
        item { ServiceCard("🎫 Exam PIN", "WAEC • NECO • JAMB • NABTEB", onExamPin) }
        item {
            Text(
                "Wallet da transaction ana tabbatar da su a backend kafin kammala sayayya.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun ServiceCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            Text(subtitle)
            Spacer(Modifier.height(10.dp))
            Button(onClick = onClick) { Text("Buɗe") }
        }
    }
}
